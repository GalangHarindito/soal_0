let s = 0;
let angka = 23
for (let i = 2;i<angka;i++){
    
}
console.log(s)