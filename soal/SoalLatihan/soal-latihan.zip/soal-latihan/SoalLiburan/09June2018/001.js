function soal1(param){
    if(param === 0){
    	return "invalid input"
    }

  var result = []
    for(var i = 0; i<param; i++){
    	// console.log(i)
    	result.push("")
    }
    // console.log(Math.floor(result.length/2))
    var center = result.length

    if(param % 2 === 0){
    	result[(center-2)/2] = "*"
    	result[(center-2)/2 + 1] = "*"
    } else {
    	result[Math.trunc(center/2)] = "*"
    }
    console.log(result)
}

// test case
console.log( soal1(5) ) 
/*
    output : 
    ['','','*','','']
*/

console.log( soal1(4)) // ['','*','*','']

console.log( soal1(7)) // ['','','','*','','','']

console.log( soal1(10)) // ['','','','','*','*','','','','']

console.log( soal1(0)) // invalid input 

console.log( soal1(1)) // ['*']