
function soal2(param){

	if(param.length < 5) {
		return "invalid input"
	}
	
	var result = param[0] * param[param.length - 1];
	var arr = []
	for (var i = 0; i < param.length; i++) {
		// console.log(param[i])
		arr.push(param[i])
	}

	if(arr.length === 5) {
		arr.splice(2, 1, result)
	} else if(arr.length === 7){
		arr.splice(3, 1, result)
	} else if (arr.length === 8) {
		arr.splice(3, 1, result)
		arr.splice(4, 1, result)
	}

	return arr

}

console.log(soal2([34,'','','',40]))
// [34,''1360,'',40]

console.log(soal2([1,2,3,4,5]))
// [1,2,5,4,5]

console.log(soal2([20,'','','','','','',30]))
// [20,'','',600,600,'','',30])

console.log(soal2([6,'','','','','',9]))
// [6,'','',54,'','',9]

console.log(soal2([1,2])) // invalid input 
console.log(soal2([1])) // invalid input 
console.log(soal2([])) // invalid input 