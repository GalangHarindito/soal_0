
function soal3(param1){

    var result = []
    var counter = 1

    for(var i = 0; i < param1; i++){
        // console.log(i)
        result.push([])
        for (var j = 0; j < param1; j++) {
            if(i%2 === 0){
                result[i].push(j+counter)
            } else {
                result[i].unshift(j+counter)
            }
        }
        counter += param1
      }
}

console.log(soal3(3))
/*
    [
        [1,2,3],
        [6,5,4],
        [7,8,9]
    ]

*/

console.log(soal3(2))
/*
    [
        [1,2],
        [4,3]
    ]

*/

console.log(soal3(4))
/*
    [
        [1,2,3,4],
        [8,7,6,5],
        [9,10,11,12],
        [16,15,15,13]
    ]

*/
