/*
    analisa sendiri dengan apa yang diminta soal melalui test case. 
    wajib menggunakan pseudocode

    PSEUDOCODE HERE : 

STORE result with the value of Array

	IF param is empty
		DISPLAY "Invalid Input!"
	END IF 

STORE result with the value of Array

	FOR LOOP in param
		IF index is equal to 0
			result push "!";
		ELSE IF result[i-1] equals to "!"
			result push "@";
		ELSE IF re



*/
function soal1(param){

	var result = [];

	if(!param){
		return "Invalid Input!"
	}

	for (var i = 0; i < param; i++) {
		if(i === 0){
			result.push("!")
		} else if (result[i-1] === "!"){
			result.push("@");
		} else if (result[i-1] === "@"){
			result.push("#")
		} else if (result[i-1] === "#"){
			result.push("!")
		}
	}
	return result
}

console.log(soal1(3))
// output : ['!','@','#']

console.log(soal1(6));
// output : ['!','@','#','!','@','#']

console.log(soal1(4))
// output : ['!','@','#','!']

console.log(soal1(0)) // invalid input