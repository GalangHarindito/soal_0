
function soal1(param){

    for (var i = param.length-1; i >= 0; i--) {
        console.log(param[i])
    }

}

console.log(soal1("Aries Dimas Yudhistira"));
/*
    a
    r
    i
    t
    s
    i
    h
    d
    u
    Y

    s
    a
    m
    i
    D

    s
    e
    i
    r
    A
*/