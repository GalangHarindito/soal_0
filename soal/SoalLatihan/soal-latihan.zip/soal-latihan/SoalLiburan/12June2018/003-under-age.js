function soal3(param){
  
  var under = []
  var older = []
  for(var i in param) {
//     console.log(param[i][1])
    if(param[i][1] < 20){
      under.push(param[i][0])
    } else if (param[i][1] > 20){
      older.push(param[i][0])
    }
    
    var obj = {}
    obj.under20 = under;
    obj.over20 = older;
  }  
  return obj
}

console.log(soal3([
    ["dimas",17],
    ["akbar",28],
    ["rifki",30],
    ["dimitri",18],
    ["saitama",19]
]));

/*
    {
        under20:["dimas",'dimitri','saitama'],
        over20:["akbar","rifki"]
    }
*/
