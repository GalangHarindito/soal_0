function soal1(param)
{
    // your code here
}

console.log("Aries Dimas Yudhistira");
/*
    a
    r
    i
    t
    s
    i
    h
    d
    u
    Y

    s
    a
    m
    i
    D

    s
    e
    i
    r
    A
*/