
/*
Tranpose the Matrix
================
Author: Muhammad Ramadiansyah
Description: matrixTranspose adalah sebuah fungsi untuk menukar posisi baris dan kolom
              dari sebuah matriks
Examples:
1. input = [
  [1, 2],
  [3, 4],
  [5, 6]
]
  output = [
    [1, 3, 5],
    [2, 4, 6]
  ]
2. input = [
    [1, 2]
]
  output = [
    [1],
    [2]
  ]
*/
function matrixTranspose(matriks) {
  for (var i=0; i<matriks.length; i++) {
    // console.log(matriks[i]);
    for (var j=0; j<matriks[i].length; j++) {
      console.log(matriks[i], matriks[i][j]);
      
    }
  }
}

/*
kesamping: 4 (looping 2)
kebawah: 2 (looping 1)


*/

console.log(matrixTranspose([[1, 2], [3, 4], [5, 6], [7, 8]]))
/*
  input:
  [
    [1, 2],
    [3, 4],
    [5, 6]
  ]
  output :
  [
    [1, 3, 5, 7],
    [2, 4, 6, 8]
  ]
*/

// looping 1: ke bawah 
      // var temp = []
//     looping 2: ke samping push
//  return temp

// console.log(matrixTranspose([[1, 2], [3, 4]]));

// /*
//   input:
//   [
//     [1, 2],
//     [3, 4]
//   ]
//   output :
//   [
//     [1, 3],
//     [2, 4]
//   ]
// */

// console.log(matrixTranspose([[1, 2]]))
// /*
//   input:
//   [
//     [1, 2]  
//   ]
//   output :
//   [
//     [1],
//     [2]
//   ]
// */

// console.log(tranpose_matriks([[1, 2, 3], [4, 5, 6], [7, 8, 9]]))
// /*
//   input = [
//     [1, 2, 3],
//     [4, 5, 6],
//     [7, 8, 9]
//   ]
//     output = [
//       [1, 4, 7],
//       [2, 5, 8],
//       [3, 6, 9]
//     ]
// */