function threeVowels (str){

}

console.log(threeVowels("caaaal meeee"))