/*
============================
Count Passing Students
============================

[INSTRUCTIONS]
Terdapat fungsi count passing students yang menerima 1 parameter berupa array.
Fungsi ini akan mengeluarkan output berupa string untuk menampilkan berapa jumlah siswa yang lulus ujian dan rata - rata nilai siswa yang lulus ujian.
Siswa dinyatakan lulus ujian jika memiliki nilai diatas 70

[EXAMPLE]
input : [80, 90, 70, 60, 30, 100]
output : 3 Siswa lulus ujian, rata - rata nilai siswa yang lulus : 90

input : [80, 85, 75, 60, 40, 97]
output : 4 Siswa lulus ujian, rata - rata nilai siswa yang lulus : 84

input : [10, 30, 70, 0]
output : Tidak ada siswa yang lulus ujian

[RULE]
- WAJIB MENGGUNAKAN ALGORITMA / PSEUDOCODE
- Hanya boleh menggunakan loop, kondisional, dan .push

*/

function countPassingStudents (arr) {
  //your code here
}

console.log(countPassingStudents([80, 90, 70, 60, 30, 100]))
// 3 Siswa lulus ujian, rata - rata nilai siswa yang lulus : 90

console.log(countPassingStudents([80, 85, 75, 60, 40, 97]))
// 4 Siswa lulus ujian, rata - rata nilai siswa yang lulus : 84

console.log(countPassingStudents([10, 30, 70, 0]))
// Tidak ada siswa yang lulus ujian

