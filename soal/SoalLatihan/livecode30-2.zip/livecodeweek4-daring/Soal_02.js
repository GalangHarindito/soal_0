/*
============================
NAME TERMINATOR
============================

[INSTRUCTIONS]
Terdapat fungsi name terminator yang menerima 2 parameter : 
 - parameter pertama berupa array
 - parameter kedua berupa string
Fungsi ini berguna untuk mengeliminasi nama dalam array yang memiliki nama depan sama dengan parameter kedua

[EXAMPLE]
input parameter 1 : ['Hatsune Miku', 'Uzumaki Naruto', 'Nobi Nobita', 'Uzumaki Hinata']
input parameter 2 : 'Uzumaki'
proses : Mengeleminasi nama yang memiliki nama depan Uzumaki, maka dari itu 'Uzumaki Naruto' dan 'Uzumaki Hinata' hilang
output : ['Hatsune Miku', 'Nobi Nobita']

[RULE]
- HANYA BOLEH menggunakan loop, kondisional, dan fungsi push

*/

function nameTerminator (arr, str) {
  // your code here!
}

console.log(nameTerminator (['Hatsune Miku', 'Uzumaki Naruto', 'Nobi Nobita', 'Uzumaki Hinata'], 'Uzumaki'))
// ['Hatsune Miku', 'Nobi Nobita']

console.log(nameTerminator (['Harry Potter', 'William Harry', 'Inez Gabrina'], 'Harry'))
// ['William Harry', 'Inez Gabrina']
