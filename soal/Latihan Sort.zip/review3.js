// TEST LATIHAN 2

function manualSort() {
  
}

console.log(manualSort([[3, 4, 2], [5, 1, 6, 7]]));
/*
  [
    [2, 3, 4],
    [1, 5, 6, 7]
  ]
*/
