// TEST LATIHAN 1

function manualSort() {
  
}

console.log(manualSort([3, 4, 2, 1, 5, 6, 7]));
// [1, 2, 3, 4, 5, 6, 7]
