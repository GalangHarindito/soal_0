// Wajib menggunakan rekursif
// CHALLENGE
// RELEASE 1

function FPB(number1, number2) {
  // code below here...
};


// RELEASE 2

function KPK(number1, number2) {
  // code below here...
};

console.log(KPK(3, 4))//12
console.log(KPK(2, 35))//70

// RELEASE 3

// menghitung jam, menit, detik
function countingTime(seconds) {
  // code below here...
};

console.log(countingTime(60)); // 1 menit
console.log(countingTime(62)); // 1 menit, dan 2 detik
console.log(countingTime(3662)); // 1 jam, 1 menit, dan 2 detik
console.log(countingTime(3600)); // 1 jam
