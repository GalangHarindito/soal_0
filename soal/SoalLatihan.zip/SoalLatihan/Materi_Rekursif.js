Menggunakan Rekursif:
function sumTheNumber(number) {
	//write code here
	
	//if(...) { ... }
	//kondisi base case tempat berhentinya fungsi rekursif
	//else { ... }
	//selain kondisi base case dimana rekursif terus berlangsung
}

// ilustrate
// return 5 + F(4)
// return 5 + ( 4 + F(3) )
// return 5 + ( 4 + ( 3 + F(2) ) )
// return 5 + ( 4 + ( 3 + ( 2 + 1 )))

console.log(sumTheNumber(5)); //5

// bila bingung buat fungsi looping dengan menggunakan FOR terlebih dahulu
// kemudian coba tentukan base case serta convert menjadi fungsi rekursif
// kalau masih bingung silahkan bertanya ke buddy masing-masing