// function soal3(param){

//     var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
//     var obj = {}

//     for (var i = 0; i < alphabet.length; i++) {
//         // console.log(alphabet[i])
//         obj[alphabet[i]] = []
//         // console.log(obj)
//         for (var j = 0; j < param.length; j++) {
//             // console.log(param[j])
//             if(alphabet[i] === param[j][0]){
//                 obj[alphabet[i]].push(param[j])
//             }
//         }
//     }

//     for(var k = 0; k < alphabet.length; k++){
//         var alph = alphabet[k]
//         if(obj[alph].length === 0){
//             delete obj[alph]
//         }
//     }
//     console.log(obj)
// }

// console.log(soal3(['Ayam','Kucing','Bebek','Sapi','Babi','Curut','Cacing','Monyet']));
// /*
//     {
//         A:['Ayam'],
//         B:['Bebek','Babi'],
//         C:['Cacing','Curut'],
//         K:['Kucing'],
//         M:['Monyet'],
//         S:['Sapi']
//     }
// */

// console.log(soal3(['Anjing','Kuda','Anoa','Zebra','Lipan','Kudanil','Landak']));

// /*
//     {
//         A:['Anjing','Anoa'],
//         L:['Lipan','Landak'],
//         K:['Kuda','Kudanil'],
//         Z:['Zebra']
//     }
// */

// /*
//  for loop param 
//  if(result.studentsArr[i][0] === undefined){
    
//  }
//  */

 function soal3(param) {

    var obj = {}
    for (var i = 0; i < param.length; i++) {
        // console.log(param[i][0])
        if(obj[param[i][0]] === undefined){
            obj[param[i][0]] = [param[i]]
        } else {
            obj[param[i][0]].push(param[i])
        }
    }
    
    return obj
 }

 console.log(soal3(['Ayam','Kucing','Bebek','Sapi','Babi','Curut','Cacing','Monyet']));
/*
    {
        A:['Ayam'],
        B:['Bebek','Babi'],
        C:['Cacing','Curut'],
        K:['Kucing'],
        M:['Monyet'],
        S:['Sapi']
    }
*/

console.log(soal3(['Anjing','Kuda','Anoa','Zebra','Lipan','Kudanil','Landak']));

/*
    {
        A:['Anjing','Anoa'],
        L:['Lipan','Landak'],
        K:['Kuda','Kudanil'],
        Z:['Zebra']
    }
*/

/*
 for loop param 
 if(result.studentsArr[i][0] === undefined){
    
 }
 */