/*
    analisa sendiri dengan apa yang diminta soal melalui test case. 
    wajib menggunakan pseudocode

    PSEUDOCODE HERE : 


*/
function soal1(param) {
    if(param <= 0 ){
    	return "Invalid input"
    }

    var arr = []
    for (var i = 0; i <param; i++) {
    	
    	if(i === 0) {
    		arr.push("!")
    	} else if (arr[i-1] === "!") {
    		arr.push("@")
    	} else if(arr[i-1] === "@") {
    		arr.push("#")
    	} else if(arr[i-1] === "#") {
    		arr.push("!")
    	}
    }
    	
    return arr
}

console.log(soal1(3))
// output : ['!','@','#']

console.log(soal1(6));
// output : ['!','@','#','!','@','#']

console.log(soal1(4))
// output : ['!','@','#','!']

console.log(soal1(0)) // invalid input