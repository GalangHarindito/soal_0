
// // 1. setiap kelipatan 4 = Fizz
// // 2. setiap kelipatan 7 = Buzz


// function soal1(param){

// 	var result = []
//     for (var i = 0; i < param; i++) {
//     	if((i-3)%4 === 0){
//           result.push("Frizz")
//         } else if ((i-6)%7 === 0){
//           result.push("Buzz")
//         } else {
//           result.push("")
//         }
//     }
//   return result
// }

// console.log(soal1(20))
// // ['','','','Fizz','','','Buzz','Fizz','','','','Fizz','','Buzz','','Fizz','','','','Fizz']

// console.log(soal1(10))
// // ['','','','Fizz','','','Buzz','Fizz','','']

// console.log(soal1(30))
// // ['','','','Fizz','','','Buzz','Fizz','','','','Fizz','','Buzz','','Fizz','','','','Fizz','Buzz','','','Fizz','','','','FizzBuzz','','']


// function soal1(param){


// }

// console.log(soal1(20))
// // ['','','','Fizz','','','Buzz','Fizz','','','','Fizz','','Buzz','','Fizz','','','','Fizz']

// console.log(soal1(10))
// // ['','','','Fizz','','','Buzz','Fizz','','']

// console.log(soal1(30))
// // ['','','','Fizz','','','Buzz','Fizz','','','','Fizz','','Buzz','','Fizz','','','','Fizz','Buzz','','','Fizz','','','','FizzBuzz','','']

var height = 1;
var str = "";

  if(height < 3){
    console.log("Minimal input 3!!!")
  } else {
    for(var i = 1; i <= height; i++){
      str += i;
      console.log(str)
     }

  }