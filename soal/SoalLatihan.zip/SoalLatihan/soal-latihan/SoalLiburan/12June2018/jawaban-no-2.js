/*
    1. bikin dulu variable abjad
    2. looping, masukan terlebih dahulu rows nya
    3. baru masukin abjad
    
*/

function soal2(param){

    if(param === 0){
        return "Invalid Input"
    }

    var kamus = ""
    var start = "a".charCodeAt(0);
    var end = "z".charCodeAt(0);
    for (var i = start; i <= end; i++) {
           kamus += String.fromCharCode(i);
        }
//   console.log(kamus)
    for(var a = 0; a < kamus.length; a++){
//       console.log(kamus[a])
      if(kamus[a] == "z"){
        kamus += "z"
      } else {
        kamus += String.fromCharCode(kamus.charAt(a).charCodeAt(0)+0)
      }
    }
//   console.log(kamus)
    var arr = []
    var counter = 0
    for (var j = 0; j < param; j++) {
        arr.push([]);
        for (var k = 0; k < param; k++) {
            arr[j].push(kamus[k+counter]);
        }
      counter += param
  }
  return arr
}

console.log(soal2(8))
/*
    [
        ['a','b','c','d','e','f','g','h']
        ['i','j','k','l','m','n','o','p']
        ['q','r','s','t','u','v','w','x']
        ['y','z','a','b','c','d','e','f']
        ['g','h','i','j','k','l','m','n']
        ['o','p','q','r','s','t','u','v']
        ['w','x','y','z','a','b','c','d']
        ['e','f','g','h','i','j','k','l']
    ]
*/

console.log(soal2(2));
/*
    [
        ['a','b'],
        ['c','d']
    ]
*/

console.log(soal2(0)); // invalid input