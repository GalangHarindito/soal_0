/*
    wajib pseudocode. 

    Jawaban pseudocode disini 
    
*/

function soal2(param){

    var result = [];
    var alph = "abcdefghijklmnopqrstuvwxyz";
    var alphIndex = 0;

    if(param === 0){
        return "Invalid input";
    } else {

        for(var i = 0; i < param; i++){
        // console.log(i)
        result.push([]);
        for(var j = 0; j < param; j++){
            result[i].push(alph[alphIndex]);
            alphIndex++;
            if(alphIndex === alph.length){
                alphIndex = 0;
            }
        }
      }
    }
    // console.log(result)
    return result;
}

console.log(soal2(8))
/*
    [
        ['a','b','c','d','e','f','g','h']
        ['i','j','k','l','m','n','o','p']
        ['q','r','s','t','u','v','w','x']
        ['y','z','a','b','c','d','e','f']
        ['g','h','i','j','k','l','m','n']
        ['o','p','q','r','s','t','u','v']
        ['w','x','y','z','a','b','c','d']
        ['e','f','g','h','i','j','k','l']
    ]
*/

console.log(soal2(2))
/*
    [
        ['a','b'],
        ['c','d']
    ]
*/

console.log(soal2(0)) // invalid input