# SoalLiburan
soal soal js phase 0 dikerjakan selama libur lebaran 2 minggu 

# Aku gak ikutan ngerjain soal liburan deh
:(
