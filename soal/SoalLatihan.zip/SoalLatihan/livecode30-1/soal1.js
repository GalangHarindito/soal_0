/*
================
Discount Day
================

Buatlah Pseudocode untuk kasus berikut:

Sebuah restoran fast food menjual seporsi burger dengan harga 40000
Namun, harga tersebut masih bisa berkurang tergantung vocer diskon yang digunakan

- Jika vocer diskon yang digunakan adalah diskon pelajar maka harga akan diskon 20 persen
- Jika vocer diskon yang digunakan adalah diskon payGo maka harga akan diskon 30 persen
- Jika vocer diskon yang digunakan adalah diskon ofo maka harga akan diskon 25 persen
- Jika tanpa vocer diskon maka harga tetap

Tampilkan harga burger sesuai dengan vocer diskon yang digunakan pembeli 

Write Psedocode here
*/