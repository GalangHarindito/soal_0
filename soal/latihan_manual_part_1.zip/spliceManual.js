// 4. SPLICE
// splice adalah fungsi untuk menghapus atau menambahkan array, pada index tertentu
// dimana splice akan mengubah isi array tersebut
console.log('4. SPLICE');

////////////////
/// CONTOH 4 ///
////////////////

var arrayNumber = [1, 3, 2, 6, 4, 5];
var startIndex = 2;
var numberDelete = 2;
arrayNumber.splice(startIndex, numberDelete, 1, 2);
// console.log('Contoh 1:', arrayNumber);
// [ 1, 3, 1, 2, 4, 5 ]

//////////////
/// SOAL 4 ///
//////////////

function manualSplice (data, initIndex, deleteCount, insertArray) {
  // code below here
};

console.log(manualSplice([1, 3, 2, 6, 4, 5], startIndex, numberDelete, [1, 2]));
// [ 1, 3, 1, 2, 4, 5 ]
