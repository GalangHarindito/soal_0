// 1. SPLIT
// split adalah fungsi untuk merubah dari string ke array berdasarkan pemisahnya
console.log('1. Split');

////////////////
/// CONTOH 1 ///
////////////////

var exSplit1 = 'aku,kamu,dia';
var splitSeparator1 = ',';
var example1 = exSplit1.split(splitSeparator1);
// console.log('Contoh 1:', example1); // [ 'aku', 'kamu', 'dia' ]
var exSplit2 = 'aku dan kamu';
var splitSeparator2 = ' dan ';
var example2 = exSplit2.split(splitSeparator2);
// console.log('Contoh 2:', example2); // [ 'aku', 'kamu' ]

function manualSplit(string, separator) {
  // code below here
};

var answer1 = manualSplit(exSplit1, splitSeparator1);
var answer2 = manualSplit(exSplit2, splitSeparator2);
console.log(answer1); // [ 'aku', 'kamu', 'dia' ]
console.log(answer2); // [ 'aku', 'kamu' ]
